# ZESS uses only AndroidX libraries that ship their own consumer rules.
# Nothing extra needed.
