package com.zess.camera.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import android.view.animation.DecelerateInterpolator

/** Four rounded corner brackets (the square in the middle of the reference screenshot). */
class FocusReticle(ctx: Context) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xE6FFFFFF.toInt()
        strokeCap = Paint.Cap.ROUND
        strokeWidth = dp(1.6f)
    }
    private val corner = Path()

    init {
        alpha = 0f
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val inset = paint.strokeWidth
        val len = w * 0.22f
        val r = w * 0.14f
        corner.reset()
        corner.moveTo(inset, inset + len)
        corner.lineTo(inset, inset + r)
        corner.arcTo(inset, inset, inset + 2 * r, inset + 2 * r, 180f, 90f, false)
        corner.lineTo(inset + len, inset)
        pivotX = w / 2f
        pivotY = h / 2f
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        for (i in 0 until 4) {
            c.save()
            c.rotate(90f * i, cx, cy)
            c.drawPath(corner, paint)
            c.restore()
        }
    }

    /** Position the centre of the reticle at (x, y) in the parent and play the focus animation. */
    fun showAt(x: Float, y: Float, holdMs: Long = 1000) {
        translationX = x - width / 2f
        translationY = y - height / 2f
        animate().cancel()
        alpha = 0f
        scaleX = 1.4f
        scaleY = 1.4f
        animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setStartDelay(0).setDuration(220)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                animate().alpha(0f).setStartDelay(holdMs).setDuration(400).start()
            }
            .start()
    }
}
