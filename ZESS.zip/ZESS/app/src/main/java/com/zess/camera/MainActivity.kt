package com.zess.camera

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.ScaleGestureDetector
import android.view.GestureDetector
import android.view.Surface
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.ImageCapture
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.updateLayoutParams
import com.zess.camera.ui.ACCENT
import com.zess.camera.ui.FocusReticle
import com.zess.camera.ui.GlassBackdrop
import com.zess.camera.ui.GlassBar
import com.zess.camera.ui.GlassFrameLayout
import com.zess.camera.ui.GridOverlay
import com.zess.camera.ui.OptionItem
import com.zess.camera.ui.dp
import com.zess.camera.ui.dpi

/**
 * ZESS: full-screen viewfinder with a floating frosted-glass control bar.
 * The whole UI is built in code (no XML layouts, no Compose) to keep the app tiny and fast.
 */
class MainActivity : ComponentActivity() {

    // ---- views
    private lateinit var root: FrameLayout
    private lateinit var preview: PreviewView
    private lateinit var backdrop: GlassBackdrop
    private lateinit var grid: GridOverlay
    private lateinit var reticle: FocusReticle
    private lateinit var countdownText: TextView
    private lateinit var flashOverlay: View
    private lateinit var topPill: GlassFrameLayout
    private lateinit var chevron: ImageView
    private lateinit var panel: GlassFrameLayout
    private lateinit var bar: GlassBar
    private lateinit var permissionView: TextView
    private lateinit var flashItem: OptionItem
    private lateinit var timerItem: OptionItem
    private lateinit var gridItem: OptionItem

    private lateinit var engine: CameraEngine

    // ---- state
    private val prefs by lazy { getSharedPreferences("zess", MODE_PRIVATE) }
    private val flashModes = intArrayOf(
        ImageCapture.FLASH_MODE_OFF, ImageCapture.FLASH_MODE_AUTO, ImageCapture.FLASH_MODE_ON
    )
    private val flashLabels = arrayOf("Off", "Auto", "On")
    private val timerValues = intArrayOf(0, 3, 10)
    private var flashIdx = 0
    private var timerIdx = 0
    private var gridOn = true
    private var hasFlash = true

    private var started = false
    private var panelOpen = false
    private var capturing = false
    private var countdown: Runnable? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) onPermissionGranted() else permissionView.visibility = View.VISIBLE
        }

    private val orientationListener by lazy {
        object : OrientationEventListener(this) {
            override fun onOrientationChanged(o: Int) {
                if (o == ORIENTATION_UNKNOWN) return
                val rot = when (o) {
                    in 45..134 -> Surface.ROTATION_270
                    in 135..224 -> Surface.ROTATION_180
                    in 225..314 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                }
                engine.setRotation(rot)
            }
        }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        flashIdx = prefs.getInt("flash", 0).coerceIn(0, 2)
        timerIdx = prefs.getInt("timer", 0).coerceIn(0, 2)
        gridOn = prefs.getBoolean("grid", true)

        buildUi()
        setContentView(root)
        refreshOptionLabels()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    panelOpen -> setPanel(false)
                    bar.mode != GlassBar.Mode.MAIN -> bar.setMode(GlassBar.Mode.MAIN)
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        if (hasCameraPermission()) onPermissionGranted()
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    override fun onResume() {
        super.onResume()
        backdrop.start()
        if (orientationListener.canDetectOrientation()) orientationListener.enable()
        if (!started && hasCameraPermission()) onPermissionGranted()
    }

    override fun onPause() {
        backdrop.stop()
        orientationListener.disable()
        cancelCountdown()
        super.onPause()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.repeatCount == 0) onShutter()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED

    private fun onPermissionGranted() {
        permissionView.visibility = View.GONE
        if (started) return
        started = true

        engine.flashMode = flashModes[flashIdx]
        engine.start()
        reticle.post { reticle.showAt(root.width / 2f, root.height / 2f, 1400) }

        // Lens detection reads Camera2 metadata; do it off the main thread.
        Thread {
            val found = LensProbe.probe(this)
            runOnUiThread { bar.setLenses(found) }
        }.start()
    }

    // ------------------------------------------------------------------ UI construction

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        preview = PreviewView(this).apply {
            // COMPATIBLE = TextureView, needed for the live glass backdrop.
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
            setBackgroundColor(Color.BLACK)
        }
        root.addView(preview, match())
        backdrop = GlassBackdrop(preview)
        engine = CameraEngine(this, preview)

        grid = GridOverlay(this).apply { visibility = if (gridOn) View.VISIBLE else View.GONE }
        root.addView(grid, match())

        reticle = FocusReticle(this)
        root.addView(reticle, FrameLayout.LayoutParams(dpi(84), dpi(84), Gravity.TOP or Gravity.START))

        countdownText = TextView(this).apply {
            textSize = 120f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setShadowLayer(dp(12), 0f, 0f, 0x66000000)
            visibility = View.GONE
        }
        root.addView(countdownText, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
        ))

        flashOverlay = View(this).apply {
            setBackgroundColor(Color.WHITE)
            alpha = 0f
        }
        root.addView(flashOverlay, match())

        buildTopPill()
        buildPanel()
        buildBar()

        permissionView = TextView(this).apply {
            text = "ZESS needs camera access\nTap to allow"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xB3FFFFFF.toInt())
            visibility = View.GONE
            setOnClickListener {
                if (shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
                    permissionLauncher.launch(Manifest.permission.CAMERA)
                } else {
                    startActivity(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.fromParts("package", packageName, null)
                        )
                    )
                }
            }
        }
        root.addView(permissionView, match())

        setupPreviewTouch()
        setupEngineCallbacks()

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            topPill.updateLayoutParams<FrameLayout.LayoutParams> { topMargin = b.top + dpi(8) }
            panel.updateLayoutParams<FrameLayout.LayoutParams> { topMargin = b.top + dpi(8 + 28 + 10) }
            bar.updateLayoutParams<FrameLayout.LayoutParams> { bottomMargin = b.bottom + dpi(36) }
            insets
        }
    }

    private fun match() = FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
    )

    private fun buildTopPill() {
        chevron = ImageView(this).apply { setImageResource(R.drawable.ic_chevron) }
        topPill = GlassFrameLayout(this, backdrop).apply {
            contentDescription = "Options"
            addView(chevron, FrameLayout.LayoutParams(dpi(22), dpi(22), Gravity.CENTER))
            setOnClickListener {
                performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                setPanel(!panelOpen)
            }
        }
        root.addView(
            topPill,
            FrameLayout.LayoutParams(dpi(52), dpi(28), Gravity.TOP or Gravity.CENTER_HORIZONTAL)
                .apply { topMargin = dpi(40) }
        )
    }

    private fun buildPanel() {
        flashItem = OptionItem(this, R.drawable.ic_flash)
        timerItem = OptionItem(this, R.drawable.ic_timer)
        gridItem = OptionItem(this, R.drawable.ic_grid)

        flashItem.setOnClickListener {
            flashIdx = (flashIdx + 1) % flashModes.size
            engine.setFlash(flashModes[flashIdx])
            prefs.edit().putInt("flash", flashIdx).apply()
            refreshOptionLabels()
        }
        timerItem.setOnClickListener {
            timerIdx = (timerIdx + 1) % timerValues.size
            prefs.edit().putInt("timer", timerIdx).apply()
            refreshOptionLabels()
        }
        gridItem.setOnClickListener {
            gridOn = !gridOn
            grid.visibility = if (gridOn) View.VISIBLE else View.GONE
            prefs.edit().putBoolean("grid", gridOn).apply()
            refreshOptionLabels()
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            for (item in listOf(flashItem, timerItem, gridItem)) {
                addView(item, LinearLayout.LayoutParams(dpi(62), dpi(54)))
            }
        }
        panel = GlassFrameLayout(this, backdrop).apply {
            cornerPx = dp(26)
            setPadding(dpi(8), dpi(6), dpi(8), dpi(6))
            addView(row, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ))
            visibility = View.INVISIBLE
            alpha = 0f
        }
        root.addView(
            panel,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { topMargin = dpi(8 + 28 + 10 + 32) }
        )
    }

    private fun buildBar() {
        bar = GlassBar(this, backdrop)
        root.addView(
            bar,
            FrameLayout.LayoutParams(bar.mainWidth, bar.barHeight, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
                .apply { bottomMargin = dpi(60) }
        )

        bar.shutter.setOnClickListener { onShutter() }

        bar.exposureBtn.setOnClickListener {
            bar.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            setPanel(false)
            bar.setMode(
                if (bar.mode == GlassBar.Mode.EXPOSURE) GlassBar.Mode.MAIN else GlassBar.Mode.EXPOSURE
            )
        }
        bar.lensBtn.setOnClickListener {
            bar.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            setPanel(false)
            bar.setMode(GlassBar.Mode.LENS)
        }

        bar.slider.onTouching = { bar.bump() }
        bar.slider.onChange = { v -> bar.setEv(engine.setExposure(v)) }

        bar.onLensPicked = { lens ->
            bar.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            engine.selectLens(lens)
            bar.postDelayed({ bar.setMode(GlassBar.Mode.MAIN) }, 280)
        }
    }

    private fun setupEngineCallbacks() {
        engine.onZoom = { z -> bar.setZoom(z, engine.front) }
        engine.onBound = { flash, evSupported ->
            hasFlash = flash
            refreshOptionLabels()
            bar.exposureBtn.isEnabled = evSupported
            bar.exposureBtn.alpha = if (evSupported) 1f else 0.35f
            bar.setEv(engine.setExposure(bar.slider.value))
        }
    }

    private fun setupPreviewTouch() {
        val scale = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                engine.zoomBy(d.scaleFactor)
                return true
            }
        })
        val taps = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (!scale.isInProgress) onViewfinderTap(e.x, e.y)
                return true
            }
        })
        preview.setOnTouchListener { _, e ->
            scale.onTouchEvent(e)
            taps.onTouchEvent(e)
            true
        }
    }

    private fun onViewfinderTap(x: Float, y: Float) {
        if (panelOpen) setPanel(false)
        if (bar.mode == GlassBar.Mode.LENS) bar.setMode(GlassBar.Mode.MAIN)
        engine.focus(x, y)
        reticle.showAt(x, y)
    }

    // ------------------------------------------------------------------ options panel

    private fun refreshOptionLabels() {
        flashItem.set(flashLabels[flashIdx], flashIdx != 0, hasFlash)
        val t = timerValues[timerIdx]
        timerItem.set(if (t == 0) "Off" else "${t}s", t != 0)
        gridItem.set(if (gridOn) "On" else "Off", gridOn)
    }

    private fun setPanel(open: Boolean) {
        if (open == panelOpen) return
        panelOpen = open
        chevron.animate().rotation(if (open) 180f else 0f).setDuration(220).start()
        panel.animate().cancel()
        if (open) {
            panel.pivotX = panel.width / 2f
            panel.pivotY = 0f
            panel.visibility = View.VISIBLE
            panel.alpha = 0f
            panel.translationY = -dp(8)
            panel.scaleX = 0.92f
            panel.scaleY = 0.92f
            panel.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setDuration(220).setInterpolator(DecelerateInterpolator()).start()
        } else {
            panel.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f)
                .setDuration(150)
                .withEndAction { if (!panelOpen) panel.visibility = View.INVISIBLE }
                .start()
        }
    }

    // ------------------------------------------------------------------ shutter

    private fun onShutter() {
        if (countdown != null) {
            cancelCountdown()
            return
        }
        val seconds = timerValues[timerIdx]
        if (seconds <= 0) takePhoto() else startCountdown(seconds)
    }

    private fun startCountdown(seconds: Int) {
        setPanel(false)
        bar.setMode(GlassBar.Mode.MAIN)
        var left = seconds
        val r = object : Runnable {
            override fun run() {
                if (left <= 0) {
                    countdown = null
                    countdownText.visibility = View.GONE
                    takePhoto()
                    return
                }
                countdownText.text = left.toString()
                countdownText.visibility = View.VISIBLE
                countdownText.alpha = 1f
                countdownText.scaleX = 1.15f
                countdownText.scaleY = 1.15f
                countdownText.animate().scaleX(1f).scaleY(1f).setDuration(600).start()
                bar.shutter.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                left--
                root.postDelayed(this, 1000)
            }
        }
        countdown = r
        r.run()
    }

    private fun cancelCountdown() {
        countdown?.let { root.removeCallbacks(it) }
        countdown = null
        if (::countdownText.isInitialized) countdownText.visibility = View.GONE
    }

    private fun takePhoto() {
        if (capturing) return
        capturing = true
        bar.shutter.pulse()
        bar.shutter.performHapticFeedback(
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM
            else HapticFeedbackConstants.VIRTUAL_KEY
        )
        flashOverlay.animate().cancel()
        flashOverlay.alpha = 0.85f
        flashOverlay.animate().alpha(0f).setDuration(200).start()

        engine.capture { ok ->
            capturing = false
            if (!ok) Toast.makeText(this, "Couldn't save photo", Toast.LENGTH_SHORT).show()
        }
    }
}
