package com.zess.camera.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import com.zess.camera.LensProbe
import com.zess.camera.R

/** One lens in the lens picker: "0.5", "1", "3" or the selfie glyph. Selected one shows live zoom. */
class LensChip(ctx: Context, val lens: LensProbe.Lens) : FrameLayout(ctx) {

    private val label = TextView(ctx)
    private val icon = ImageView(ctx)

    init {
        label.gravity = Gravity.CENTER
        label.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        addView(
            label,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        val p = dpi(11)
        icon.setPadding(p, p, p, p)
        icon.setImageResource(R.drawable.ic_selfie)
        addView(
            icon,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        label.visibility = if (lens.front) GONE else VISIBLE
        icon.visibility = if (lens.front) VISIBLE else GONE
        isClickable = true
        pressFeedback()
    }

    fun bind(selected: Boolean, zoom: Float) {
        background = if (selected) circleBg(0x66000000) else null
        val color = if (selected) ACCENT else Color.argb(235, 255, 255, 255)
        if (lens.front) {
            icon.setColorFilter(color)
        } else {
            label.text = if (selected) fmtZoom(zoom) + "×" else fmtZoom(lens.ratio)
            label.setTextColor(color)
            label.textSize = if (selected) 14f else 12.5f
        }
    }
}
