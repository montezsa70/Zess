package com.zess.camera.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.min

/** Red ring + white disk, exactly like the reference UI. The disk squeezes when pressed. */
class ShutterButton(ctx: Context) : View(ctx) {

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = SHUTTER_RED
    }
    private val disk = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private var diskScale = 1f
    private var anim: ValueAnimator? = null

    init {
        isClickable = true
        contentDescription = "Shutter"
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val outer = min(width, height) / 2f
        val sw = dp(5.5f)
        ring.strokeWidth = sw
        c.drawCircle(cx, cy, outer - sw / 2f, ring)
        c.drawCircle(cx, cy, (outer - sw - dp(0.6f)) * diskScale, disk)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> animateTo(0.86f, 90)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> animateTo(1f, 180)
        }
        return super.onTouchEvent(e)
    }

    /** Quick "snap" used when a photo is taken. */
    fun pulse() {
        animateTo(0.72f, 70)
        postDelayed({ animateTo(1f, 220) }, 80)
    }

    private fun animateTo(target: Float, ms: Long) {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(diskScale, target).apply {
            duration = ms
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                diskScale = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }
}
