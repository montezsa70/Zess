package com.zess.camera.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Tick-mark slider for exposure compensation. Value runs -1..1 and is mapped to the camera's
 * real EV range by the engine. Dragging snaps to 0 near the centre and gives a light haptic tick.
 */
class ExposureSlider(ctx: Context) : View(ctx) {

    var value = 0f
        private set

    var onChange: ((Float) -> Unit)? = null
    var onTouching: (() -> Unit)? = null

    private val ticks = 41
    private var lastTick = ticks / 2

    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeWidth = dp(1.6f)
    }
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumbRect = RectF()

    fun setValue(v: Float) {
        value = v.coerceIn(-1f, 1f)
        lastTick = Math.round((value + 1f) / 2f * (ticks - 1))
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = dp(10)
        val span = w - 2 * pad
        val cy = h / 2f
        val centerX = pad + span / 2f
        val thumbX = pad + (value + 1f) / 2f * span

        val lo = min(centerX, thumbX) - 0.5f
        val hi = max(centerX, thumbX) + 0.5f

        for (i in 0 until ticks) {
            val x = pad + i.toFloat() / (ticks - 1) * span
            val major = i % 5 == 0
            val half = when {
                i == ticks / 2 -> dp(11)
                major -> dp(8)
                else -> dp(4.5f)
            }
            tickPaint.color =
                if (value != 0f && x >= lo && x <= hi) ACCENT
                else Color.argb(if (major) 175 else 110, 255, 255, 255)
            c.drawLine(x, cy - half, x, cy + half, tickPaint)
        }

        thumbPaint.color = if (value != 0f) ACCENT else WHITE
        val tw = dp(3.5f)
        val th = dp(30)
        thumbRect.set(thumbX - tw / 2f, cy - th / 2f, thumbX + tw / 2f, cy + th / 2f)
        c.drawRoundRect(thumbRect, tw / 2f, tw / 2f, thumbPaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                onTouching?.invoke()
                update(e.x)
            }
            MotionEvent.ACTION_MOVE -> {
                onTouching?.invoke()
                update(e.x)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                parent?.requestDisallowInterceptTouchEvent(false)
        }
        return true
    }

    private fun update(x: Float) {
        val pad = dp(10)
        val span = (width - 2 * pad).coerceAtLeast(1f)
        var v = ((x - pad) / span * 2f - 1f).coerceIn(-1f, 1f)
        if (abs(v) < 0.05f) v = 0f

        val t = Math.round((v + 1f) / 2f * (ticks - 1))
        if (t != lastTick) {
            lastTick = t
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
        if (v != value) {
            value = v
            invalidate()
            onChange?.invoke(v)
        }
    }
}
