package com.zess.camera.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.widget.FrameLayout
import kotlin.math.min

/**
 * A FrameLayout that paints itself as frosted liquid glass:
 *  1. blurred copy of the camera feed behind it (see [GlassBackdrop])
 *  2. soft white tint, brighter at the top
 *  3. a thin gradient rim light, like the edge of a glass pane
 */
open class GlassFrameLayout(
    ctx: Context,
    private val backdrop: GlassBackdrop
) : FrameLayout(ctx) {

    /** Corner radius in px. Negative = full pill. */
    var cornerPx = -1f

    private val path = Path()
    private val rimRect = RectF()
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val loc = IntArray(2)
    private val ploc = IntArray(2)

    init {
        // Slightly boost saturation and darken the backdrop so the glass reads as smoky.
        val m = ColorMatrix().apply { setSaturation(1.45f) }
        val dim = ColorMatrix(
            floatArrayOf(
                0.82f, 0f, 0f, 0f, 0f,
                0f, 0.82f, 0f, 0f, 0f,
                0f, 0f, 0.82f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        m.postConcat(dim)
        bmpPaint.colorFilter = ColorMatrixColorFilter(m)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        backdrop.register(this)
    }

    override fun onDetachedFromWindow() {
        backdrop.unregister(this)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        fillPaint.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            0x30FFFFFF, 0x12FFFFFF, Shader.TileMode.CLAMP
        )
        rimPaint.strokeWidth = dp(1.1f)
        rimPaint.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            intArrayOf(0x99FFFFFF.toInt(), 0x14FFFFFF, 0x59FFFFFF),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    override fun dispatchDraw(canvas: Canvas) {
        drawGlass(canvas)
        super.dispatchDraw(canvas)
    }

    private fun drawGlass(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val r = if (cornerPx >= 0f) min(cornerPx, min(w, h) / 2f) else min(w, h) / 2f

        path.reset()
        path.addRoundRect(0f, 0f, w, h, r, r, Path.Direction.CW)

        c.save()
        c.clipPath(path)

        val src = backdrop.bitmap
        val pv = backdrop.preview
        if (src != null && pv.width > 0 && pv.height > 0) {
            getLocationInWindow(loc)
            pv.getLocationInWindow(ploc)
            c.save()
            c.translate(-(loc[0] - ploc[0]).toFloat(), -(loc[1] - ploc[1]).toFloat())
            c.scale(pv.width.toFloat() / src.width, pv.height.toFloat() / src.height)
            c.drawBitmap(src, 0f, 0f, bmpPaint)
            c.restore()
        } else {
            c.drawColor(0x33000000)
        }
        c.drawPath(path, fillPaint)
        c.restore()

        val inset = rimPaint.strokeWidth / 2f
        rimRect.set(inset, inset, w - inset, h - inset)
        val rr = (r - inset).coerceAtLeast(0f)
        c.drawRoundRect(rimRect, rr, rr, rimPaint)
    }
}
