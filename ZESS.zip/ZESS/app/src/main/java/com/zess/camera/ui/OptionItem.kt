package com.zess.camera.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Icon + tiny label used in the drop-down panel (flash, timer, grid). */
class OptionItem(ctx: Context, iconRes: Int) : LinearLayout(ctx) {

    private val icon = ImageView(ctx)
    private val label = TextView(ctx)

    init {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        icon.setImageResource(iconRes)
        addView(icon, LinearLayout.LayoutParams(dpi(22), dpi(22)))

        label.textSize = 10.5f
        label.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        label.gravity = Gravity.CENTER
        addView(label, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dpi(4)
        })
        isClickable = true
        pressFeedback()
    }

    fun set(text: String, active: Boolean, enabled: Boolean = true) {
        label.text = text
        val c = if (active) ACCENT else WHITE
        icon.setColorFilter(c)
        label.setTextColor(c)
        alpha = if (enabled) 1f else 0.35f
        isEnabled = enabled
    }
}
