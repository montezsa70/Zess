package com.zess.camera.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.zess.camera.LensProbe
import com.zess.camera.R
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * The floating glass tab bar.
 *
 *   MAIN      [ exposure ]  ( shutter )  [ 1× ]
 *   EXPOSURE  [ sun ]  |||||||||I|||||||||  +0.7
 *   LENS      [ 0.5 ]  [ 1× ]  [ 3 ]  [ selfie ]
 *
 * Switching mode animates the bar width while the old controls shrink-fade out and the new ones
 * shrink-fade in, so it reads as the same piece of glass morphing.
 */
class GlassBar(ctx: Context, backdrop: GlassBackdrop) : GlassFrameLayout(ctx, backdrop) {

    enum class Mode { MAIN, EXPOSURE, LENS }

    val exposureBtn = ImageView(ctx)
    val shutter = ShutterButton(ctx)
    val lensBtn = TextView(ctx)
    val slider = ExposureSlider(ctx)
    private val evLabel = TextView(ctx)
    private val lensRow = LinearLayout(ctx)

    var mode = Mode.MAIN
        private set
    var onLensPicked: ((LensProbe.Lens) -> Unit)? = null

    private var lenses: List<LensProbe.Lens> = emptyList()
    private val chips = ArrayList<LensChip>()
    private var currentZoom = 1f
    private var currentFront = false
    private var widthAnim: ValueAnimator? = null
    private val autoClose = Runnable { setMode(Mode.MAIN) }

    val mainWidth: Int get() = dpi(236)
    val barHeight: Int get() = dpi(68)

    init {
        // --- exposure button (left)
        exposureBtn.setImageResource(R.drawable.ic_sun)
        exposureBtn.setPadding(dpi(10), dpi(10), dpi(10), dpi(10))
        exposureBtn.background = circleBg(0x47000000)
        exposureBtn.setColorFilter(WHITE)
        exposureBtn.contentDescription = "Exposure"
        exposureBtn.pressFeedback()

        // --- lens button (right)
        lensBtn.gravity = Gravity.CENTER
        lensBtn.text = "1×"
        lensBtn.textSize = 14.5f
        lensBtn.setTextColor(WHITE)
        lensBtn.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        lensBtn.background = circleBg(0x47000000)
        lensBtn.contentDescription = "Lens"
        lensBtn.pressFeedback()

        // --- exposure slider + value
        slider.visibility = GONE
        slider.alpha = 0f
        evLabel.visibility = GONE
        evLabel.alpha = 0f
        evLabel.gravity = Gravity.CENTER
        evLabel.textSize = 13f
        evLabel.setTextColor(WHITE)
        evLabel.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setEv(0f)

        // --- lens row
        lensRow.orientation = LinearLayout.HORIZONTAL
        lensRow.gravity = Gravity.CENTER
        lensRow.visibility = GONE
        lensRow.alpha = 0f

        val s40 = dpi(40)
        addView(
            lensRow,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )
        addView(
            slider,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                dpi(48),
                Gravity.CENTER_VERTICAL
            ).apply {
                marginStart = dpi(56)
                marginEnd = dpi(54)
            }
        )
        addView(
            evLabel,
            FrameLayout.LayoutParams(dpi(44), FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.CENTER_VERTICAL)
                .apply { marginEnd = dpi(8) }
        )
        addView(
            exposureBtn,
            FrameLayout.LayoutParams(s40, s40, Gravity.START or Gravity.CENTER_VERTICAL)
                .apply { marginStart = dpi(10) }
        )
        addView(
            lensBtn,
            FrameLayout.LayoutParams(s40, s40, Gravity.END or Gravity.CENTER_VERTICAL)
                .apply { marginEnd = dpi(10) }
        )
        addView(shutter, FrameLayout.LayoutParams(dpi(60), dpi(60), Gravity.CENTER))
    }

    // ------------------------------------------------------------------ modes

    private fun group(m: Mode): List<View> = when (m) {
        Mode.MAIN -> listOf(exposureBtn, shutter, lensBtn)
        Mode.EXPOSURE -> listOf(exposureBtn, slider, evLabel)
        Mode.LENS -> listOf(lensRow)
    }

    private fun targetWidth(m: Mode): Int = when (m) {
        Mode.MAIN -> mainWidth
        Mode.EXPOSURE -> min(dpi(340), resources.displayMetrics.widthPixels - dpi(32))
        Mode.LENS -> max(mainWidth, chips.size * dpi(52) + dpi(24))
    }

    fun setMode(m: Mode) {
        if (m == mode) return
        removeCallbacks(autoClose)
        val old = group(mode)
        val new = group(m)
        mode = m

        old.filter { it !in new }.forEach { hide(it) }
        new.filter { it !in old }.forEach { show(it) }
        exposureBtn.setColorFilter(if (m == Mode.EXPOSURE) ACCENT else WHITE)
        animateWidth(targetWidth(m))
        bump()
    }

    /** Keeps an expanded bar open while the user is interacting with it. */
    fun bump() {
        removeCallbacks(autoClose)
        if (mode != Mode.MAIN) postDelayed(autoClose, 4500)
    }

    private fun hide(v: View) {
        v.animate().cancel()
        v.animate()
            .alpha(0f).scaleX(0.6f).scaleY(0.6f)
            .setStartDelay(0).setDuration(140)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction { if (v !in group(mode)) v.visibility = GONE }
            .start()
    }

    private fun show(v: View) {
        v.animate().cancel()
        if (v.visibility != VISIBLE) {
            v.alpha = 0f
            v.scaleX = 0.6f
            v.scaleY = 0.6f
            v.visibility = VISIBLE
        }
        v.animate()
            .alpha(1f).scaleX(1f).scaleY(1f)
            .setStartDelay(100).setDuration(230)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    private fun animateWidth(to: Int) {
        widthAnim?.cancel()
        val lp = layoutParams ?: return
        val from = if (width > 0) width else lp.width
        widthAnim = ValueAnimator.ofInt(from, to).apply {
            duration = 340
            interpolator = PathInterpolator(0.22f, 1f, 0.36f, 1f)
            addUpdateListener {
                lp.width = it.animatedValue as Int
                layoutParams = lp
            }
            start()
        }
    }

    // ------------------------------------------------------------------ state from the camera

    fun setEv(ev: Float) {
        evLabel.text =
            if (ev == 0f) "0.0" else String.format(Locale.US, "%+.1f", ev)
    }

    fun setLenses(list: List<LensProbe.Lens>) {
        lenses = list
        lensRow.removeAllViews()
        chips.clear()
        for (l in list) {
            val chip = LensChip(context, l)
            chip.setOnClickListener { onLensPicked?.invoke(l) }
            chips += chip
            lensRow.addView(
                chip,
                LinearLayout.LayoutParams(dpi(46), dpi(46)).apply {
                    setMargins(dpi(3), 0, dpi(3), 0)
                }
            )
        }
        setZoom(currentZoom, currentFront)
    }

    fun setZoom(z: Float, front: Boolean) {
        currentZoom = z
        currentFront = front
        lensBtn.text = fmtZoom(z) + "×"
        if (chips.isEmpty()) return
        val sel = if (front) {
            lenses.indexOfFirst { it.front }
        } else {
            lenses.indices.lastOrNull { !lenses[it].front && lenses[it].ratio <= z * 1.02f } ?: 0
        }
        chips.forEachIndexed { i, c -> c.bind(i == sel, z) }
    }
}
