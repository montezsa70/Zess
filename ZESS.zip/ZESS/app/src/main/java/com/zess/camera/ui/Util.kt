package com.zess.camera.ui

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.view.View
import java.util.Locale
import kotlin.math.abs

val ACCENT: Int = 0xFFFFD60A.toInt()   // exposure / active yellow
val WHITE: Int = 0xFFFFFFFF.toInt()
val SHUTTER_RED: Int = 0xFFFF3B30.toInt()

fun Context.dp(v: Number): Float = v.toFloat() * resources.displayMetrics.density
fun Context.dpi(v: Number): Int = (v.toFloat() * resources.displayMetrics.density + 0.5f).toInt()
fun View.dp(v: Number): Float = context.dp(v)
fun View.dpi(v: Number): Int = context.dpi(v)

fun circleBg(color: Int): GradientDrawable = GradientDrawable().apply {
    shape = GradientDrawable.OVAL
    setColor(color)
}

/** "1", "0.5", "2.4" */
fun fmtZoom(z: Float): String {
    val r = Math.round(z)
    return if (abs(z - r) < 0.05f) "$r" else String.format(Locale.US, "%.1f", z)
}

/** Subtle press-in scale, does not consume the touch so clicks still fire. */
fun View.pressFeedback() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(0.9f).scaleY(0.9f).setStartDelay(0).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(160).start()
        }
        false
    }
}
