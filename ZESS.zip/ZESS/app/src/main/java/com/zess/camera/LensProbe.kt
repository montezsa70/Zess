package com.zess.camera

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import java.util.TreeMap
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Works out which lenses this particular phone has, using the Camera2 metadata.
 *
 * Each lens is described by:
 *  - ratio:    the number shown in the UI (0.5, 1, 3 ...), relative to the main camera
 *  - zoom:     the zoom ratio to apply on the camera that is bound
 *  - cameraId: non-null only when the lens is a standalone camera id that must be bound directly
 */
object LensProbe {

    data class Lens(
        val ratio: Float,
        val zoom: Float,
        val cameraId: String?,
        val front: Boolean = false
    )

    fun probe(ctx: Context): List<Lens> {
        val result = ArrayList<Lens>()
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val all = cm.cameraIdList.mapNotNull { id ->
                try {
                    id to cm.getCameraCharacteristics(id)
                } catch (e: Exception) {
                    null
                }
            }
            val backs = all.filter {
                it.second.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
            val hasFront = all.any {
                it.second.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
            }
            if (backs.isNotEmpty()) result += backLenses(cm, backs) else result += Lens(1f, 1f, null)
            if (hasFront) result += Lens(1f, 1f, null, front = true)
        } catch (e: Exception) {
            result.clear()
            result += Lens(1f, 1f, null)
        }
        return result
    }

    private fun backLenses(
        cm: CameraManager,
        backs: List<Pair<String, CameraCharacteristics>>
    ): List<Lens> {
        val main = backs.first().second
        val mainEq = equiv(main)

        var zMin = 1f
        var zMax = main.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f
        if (Build.VERSION.SDK_INT >= 30) {
            main.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.let {
                zMin = it.lower
                zMax = it.upper
            }
        }

        val found = TreeMap<Int, Lens>()
        fun add(l: Lens) {
            val key = Math.round(l.ratio * 10f)
            val cur = found[key]
            // Prefer a lens reachable through the logical camera's zoom (smooth switching).
            if (cur == null || (cur.cameraId != null && l.cameraId == null)) found[key] = l
        }
        add(Lens(1f, 1f, null))

        if (mainEq != null && mainEq > 0f) {
            val cands = ArrayList<Pair<Float, String?>>()
            if (Build.VERSION.SDK_INT >= 28) {
                for (pid in main.physicalCameraIds) {
                    try {
                        equiv(cm.getCameraCharacteristics(pid))?.let { cands += (it / mainEq) to null }
                    } catch (e: Exception) {
                        // physical id not accessible, ignore
                    }
                }
            }
            for ((id, c) in backs.drop(1)) {
                equiv(c)?.let { cands += (it / mainEq) to id }
            }
            for ((raw, id) in cands) {
                if (abs(raw - 1f) < 0.25f) continue
                val ratio = if (raw < 1f) Math.round(raw * 10f) / 10f else Math.round(raw * 2f) / 2f
                if (id == null) {
                    val z = ratio.coerceIn(zMin, zMax)
                    if (abs(z - ratio) <= ratio * 0.15f) add(Lens(ratio, z, null))
                } else {
                    add(Lens(ratio, 1f, id))
                }
            }
        }

        // Logical camera advertises an ultra-wide through zoom ratios below 1.
        if (found.keys.none { it < 10 } && zMin < 0.95f) {
            add(Lens(Math.round(zMin * 10f) / 10f, zMin, null))
        }
        // Digital 2x when there is no optical lens in that neighbourhood.
        if (found.keys.none { it in 15..25 } && zMax >= 2f) {
            add(Lens(2f, 2f, null))
        }
        return found.values.toList().take(5)
    }

    /** 35mm-equivalent focal length, or null when the sensor does not report enough metadata. */
    private fun equiv(c: CameraCharacteristics): Float? {
        val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: return null
        val s = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: return null
        val diag = hypot(s.width, s.height)
        return if (diag > 0f) f * 43.27f / diag else null
    }
}
