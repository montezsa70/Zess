package com.zess.camera.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/** Rule-of-thirds hairlines. Never intercepts touches. */
class GridOverlay(ctx: Context) : View(ctx) {

    private val paint = Paint().apply {
        color = 0x4DFFFFFF
        style = Paint.Style.STROKE
        strokeWidth = dp(0.7f)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        for (i in 1..2) {
            c.drawLine(w * i / 3f, 0f, w * i / 3f, h, paint)
            c.drawLine(0f, h * i / 3f, w, h * i / 3f, paint)
        }
    }
}
