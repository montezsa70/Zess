package com.zess.camera.ui

import android.graphics.Bitmap
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import androidx.camera.view.PreviewView
import kotlin.math.max

/**
 * Cheap live "backdrop blur".
 *
 * ~15 times a second we copy the camera preview into a tiny bitmap (1/12 of the screen size).
 * Glass views draw that bitmap scaled back up with bilinear filtering, which gives a soft frosted
 * blur behind them. The copy is done on the GPU and the bitmap is only ~80x180 px, so it costs
 * almost nothing compared to a real blur pass.
 */
class GlassBackdrop(val preview: PreviewView) {

    companion object {
        const val DOWNSCALE = 12
        private const val INTERVAL_MS = 66L
    }

    var bitmap: Bitmap? = null
        private set

    private var texture: TextureView? = null
    private val views = ArrayList<View>()
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            refresh()
            preview.postDelayed(this, INTERVAL_MS)
        }
    }

    fun register(v: View) {
        if (!views.contains(v)) views.add(v)
    }

    fun unregister(v: View) {
        views.remove(v)
    }

    fun start() {
        if (running) return
        running = true
        preview.post(tick)
    }

    fun stop() {
        running = false
        preview.removeCallbacks(tick)
    }

    private fun findTexture(v: View): TextureView? {
        if (v is TextureView) return v
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) {
                val t = findTexture(v.getChildAt(i))
                if (t != null) return t
            }
        }
        return null
    }

    private fun refresh() {
        val w = preview.width
        val h = preview.height
        if (w == 0 || h == 0) return

        var t = texture
        if (t == null || !t.isAttachedToWindow) {
            t = findTexture(preview)
            texture = t
        }
        if (t == null || !t.isAvailable) return

        val bw = max(1, w / DOWNSCALE)
        val bh = max(1, h / DOWNSCALE)
        var b = bitmap
        if (b == null || b.width != bw || b.height != bh) {
            b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            bitmap = b
        }
        try {
            t.getBitmap(b)
        } catch (e: Throwable) {
            return
        }
        for (v in views) v.invalidate()
    }
}
