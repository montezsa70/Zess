# ZESS

Ultra-minimal, full-screen camera for Android. Kotlin + CameraX, no Compose, no third-party libraries.

## Build with GitHub Actions
1. Create a repo and push everything in this folder (the `.github/workflows/build.yml` is already there).
2. Open the **Actions** tab, then **Build ZESS APK**. It also runs on every push.
3. When it finishes, download the **ZESS-release** artifact. It contains `app-release.apk`.
   `ZESS-debug` is the same app with debug info.

The release APK is signed with the debug key so it installs straight away.
Use your own keystore if you ever publish to the Play Store.

The workflow installs Gradle 8.7 itself, so there is no `gradlew` or wrapper jar in the repo.
Android Studio can open the folder as is.

## What's inside
- **Full-screen viewfinder.** Preview and photo share a CameraX `ViewPort`, so saved photos have exactly the framing you see (no 4:3 / 16:9 bars).
- **Floating frosted-glass bar.** The camera feed is copied into a tiny bitmap about 15 times a second and drawn blurred behind the glass, which keeps it cheap.
- **Left: exposure.** The bar morphs into a tick slider that sets real EV compensation. Tap the sun to close it, or it closes after 4.5 s.
- **Right: lenses.** The bar morphs into the lenses this phone actually has. They come from Camera2 metadata: ultra-wide, main, telephotos (or a digital 2x if there is none), and selfie.
- **Chevron at the top.** Opens flash, timer (3 s / 10 s) and grid.
- **Gestures.** Tap to focus, pinch to zoom. The volume keys are shutter buttons.
- **Saving.** Photos go to `Pictures/ZESS` through MediaStore, so no storage permission is needed. The only permission is the camera.

## Layout
```
app/src/main/java/com/zess/camera/
  MainActivity.kt      UI wiring, gestures, timer, shutter
  CameraEngine.kt      CameraX binding, zoom, exposure, focus, capture
  LensProbe.kt         detects the phone's lenses
  ui/                  GlassFrameLayout, GlassBar, GlassBackdrop, ExposureSlider, ShutterButton, ...
```

Requires Android 10 (API 29) or newer. Portrait only.

## Film looks
Tap the film icon (bottom right, above the bar) to pick a look: Original, Noir, Grain, Cinema, Blockbuster, Vivid.
The look is shown live in the viewfinder, and the saved photo has it applied (the plain version is not kept).
Processing runs in the background, so a photo appears in the gallery about a second after the shot.

## Swipe
Swipe left on the viewfinder to open your last photo.
