package com.zess.camera

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ColorMatrix
import kotlin.math.abs
import kotlin.math.min

/**
 * The film looks. Each one is a colour matrix (saturation, tint, contrast, lifted/crushed blacks)
 * plus optional grain and vignette strength. The same numbers drive the live preview and the
 * processing of the saved photo, so what you see is what you get.
 */
enum class FilmLook(
    val label: String,
    private val sat: Float,
    private val contrast: Float,
    private val gain: FloatArray,      // per-channel multiplier (warm / cool cast)
    private val offset: FloatArray,    // per-channel shift, 0..255 (lifted or tinted blacks)
    val grain: Float,                  // 0..1
    val vignette: Float                // 0..1
) {
    ORIGINAL("Original", 1f, 1f, floatArrayOf(1f, 1f, 1f), floatArrayOf(0f, 0f, 0f), 0f, 0f),

    NOIR("Noir", 0f, 1.3f, floatArrayOf(1f, 1f, 1f), floatArrayOf(-4f, -4f, -4f), 0.55f, 0.40f),

    GRAIN("Grain", 0.85f, 1.05f, floatArrayOf(1.06f, 1.0f, 0.90f), floatArrayOf(14f, 10f, 4f), 0.90f, 0.25f),

    CINEMA("Cinema", 0.80f, 1.12f, floatArrayOf(0.98f, 1.0f, 1.02f), floatArrayOf(2f, 6f, 10f), 0.30f, 0.35f),

    BLOCKBUSTER("Blockbuster", 1.10f, 1.22f, floatArrayOf(1.10f, 1.0f, 0.92f), floatArrayOf(-8f, 2f, 10f), 0.20f, 0.30f),

    VIVID("Vivid", 1.5f, 1.10f, floatArrayOf(1.02f, 1.02f, 1.02f), floatArrayOf(0f, 0f, 0f), 0f, 0f);

    /** null for ORIGINAL (nothing to apply). */
    val colorMatrix: ColorMatrix? by lazy {
        if (this == ORIGINAL) null else build()
    }

    private fun build(): ColorMatrix {
        val m = ColorMatrix()
        m.setSaturation(sat)
        m.postConcat(
            ColorMatrix(
                floatArrayOf(
                    gain[0], 0f, 0f, 0f, 0f,
                    0f, gain[1], 0f, 0f, 0f,
                    0f, 0f, gain[2], 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
        val t = 128f * (1f - contrast)
        m.postConcat(
            ColorMatrix(
                floatArrayOf(
                    contrast, 0f, 0f, 0f, t + offset[0],
                    0f, contrast, 0f, 0f, t + offset[1],
                    0f, 0f, contrast, 0f, t + offset[2],
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
        return m
    }

    companion object {
        /** Tileable zero-mean film grain: white and black specks of random strength. */
        val noise: Bitmap by lazy {
            val size = 128
            val rnd = java.util.Random(42)
            val px = IntArray(size * size)
            for (i in px.indices) {
                val v = (rnd.nextInt(256) + rnd.nextInt(256)) / 2
                val a = min(255, abs(v - 128) * 3)
                px[i] = if (v >= 128) Color.argb(a, 255, 255, 255) else Color.argb(a, 0, 0, 0)
            }
            Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
        }
    }
}
