package com.zess.camera.ui

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.zess.camera.FilmLook
import com.zess.camera.R

/** Round glass button with the film icon. Turns yellow while a look is active. */
class FilmButton(ctx: Context, backdrop: GlassBackdrop) : GlassFrameLayout(ctx, backdrop) {

    private val icon = ImageView(ctx)

    init {
        icon.setImageResource(R.drawable.ic_film)
        addView(icon, FrameLayout.LayoutParams(dpi(24), dpi(24), Gravity.CENTER))
        contentDescription = "Film looks"
        isClickable = true
        pressFeedback()
        setActive(false)
    }

    fun setActive(active: Boolean) {
        icon.setColorFilter(if (active) ACCENT else WHITE)
    }
}

/** Glass pill with one chip per film look. Scrolls sideways if it does not fit. */
class FilmPicker(ctx: Context, backdrop: GlassBackdrop) : GlassFrameLayout(ctx, backdrop) {

    var onPick: ((FilmLook) -> Unit)? = null
    private val chips = LinkedHashMap<FilmLook, TextView>()

    init {
        isClickable = true

        val scroll = HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            isFillViewport = true
        }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        for (look in FilmLook.values()) {
            val tv = TextView(ctx).apply {
                text = look.label
                textSize = 12.5f
                gravity = Gravity.CENTER
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setPadding(dpi(13), 0, dpi(13), 0)
                pressFeedback()
                setOnClickListener { onPick?.invoke(look) }
            }
            chips[look] = tv
            row.addView(
                tv,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dpi(38)).apply {
                    setMargins(dpi(2), 0, dpi(2), 0)
                }
            )
        }
        scroll.addView(
            row,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        addView(
            scroll,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                .apply { setMargins(dpi(8), 0, dpi(8), 0) }
        )
        select(FilmLook.ORIGINAL)
    }

    fun select(look: FilmLook) {
        for ((l, tv) in chips) {
            val sel = l == look
            tv.setTextColor(if (sel) ACCENT else 0xD9FFFFFF.toInt())
            tv.background = if (sel) {
                GradientDrawable().apply {
                    cornerRadius = dp(19)
                    setColor(0x66000000)
                }
            } else null
        }
    }
}
