package com.zess.camera.ui

import android.content.Context
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import com.zess.camera.FilmLook
import java.util.Random
import kotlin.math.hypot

/** Live vignette + animated grain on top of the preview. Never intercepts touches. */
class LookOverlay(ctx: Context, private val backdrop: GlassBackdrop) : View(ctx) {

    private val vignette = Paint()
    private val grain = Paint(Paint.FILTER_BITMAP_FLAG)
    private val noiseShader = BitmapShader(FilmLook.noise, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    private val gm = Matrix()
    private val rnd = Random()

    init {
        grain.shader = noiseShader
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        backdrop.register(this)   // gets invalidated on every backdrop tick, so the grain "moves"
    }

    override fun onDetachedFromWindow() {
        backdrop.unregister(this)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        vignette.shader = RadialGradient(
            w / 2f, h / 2f, hypot(w.toFloat(), h.toFloat()) / 2f,
            intArrayOf(0, 0, Color.BLACK), floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        val look = backdrop.look
        val w = width.toFloat()
        val h = height.toFloat()
        if (look.vignette > 0f) {
            vignette.alpha = (look.vignette * 255).toInt()
            c.drawRect(0f, 0f, w, h, vignette)
        }
        if (look.grain > 0f) {
            val s = w / 1080f * 1.5f
            gm.setScale(s, s)
            gm.postTranslate(rnd.nextInt(256).toFloat(), rnd.nextInt(256).toFloat())
            noiseShader.setLocalMatrix(gm)
            grain.alpha = (look.grain * 110).toInt()
            c.drawRect(0f, 0f, w, h, grain)
        }
    }
}
