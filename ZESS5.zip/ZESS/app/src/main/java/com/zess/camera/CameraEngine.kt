@file:OptIn(androidx.camera.camera2.interop.ExperimentalCamera2Interop::class)

package com.zess.camera

import android.animation.ValueAnimator
import android.util.Size
import android.view.animation.DecelerateInterpolator
import androidx.activity.ComponentActivity
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.core.Camera
import androidx.camera.core.CameraFilter
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.UseCaseGroup
import androidx.camera.core.ZoomState
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import java.util.concurrent.TimeUnit

/**
 * Everything that touches CameraX lives here. The UI only talks to this class.
 *
 * The Preview and ImageCapture share a ViewPort that matches the PreviewView, so the saved photo
 * has exactly the framing of the full-screen viewfinder (no 4:3 / 16:9 letterboxing).
 */
class CameraEngine(
    private val activity: ComponentActivity,
    private val previewView: PreviewView
) {
    private val mainExecutor = ContextCompat.getMainExecutor(activity)
    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null

    var front = false
        private set
    var flashMode = ImageCapture.FLASH_MODE_OFF
    private var boundId: String? = null
    private var displayBase = 1f      // multiplier for the zoom shown in the UI (standalone lens ids)
    private var rotation = android.view.Surface.ROTATION_0
    private var exposureNorm = 0f
    private var zoomAnim: ValueAnimator? = null
    private var retries = 0

    /** Zoom to display in the UI, e.g. 0.5, 1.0, 3.4 */
    var onZoom: ((Float) -> Unit)? = null

    /** Called after every (re)bind: hasFlash, exposureSupported */
    var onBound: ((Boolean, Boolean) -> Unit)? = null

    private var zoomLive: LiveData<ZoomState>? = null
    private val zoomObserver = Observer<ZoomState> { onZoom?.invoke(displayBase * it.zoomRatio) }

    fun start() {
        val future = ProcessCameraProvider.getInstance(activity)
        future.addListener({
            provider = future.get()
            bind(null, null)
        }, mainExecutor)
    }

    private fun selector(cameraId: String?): CameraSelector {
        if (front) return CameraSelector.DEFAULT_FRONT_CAMERA
        if (cameraId == null) return CameraSelector.DEFAULT_BACK_CAMERA
        return CameraSelector.Builder()
            .requireLensFacing(CameraSelector.LENS_FACING_BACK)
            .addCameraFilter(CameraFilter { infos ->
                infos.filter { Camera2CameraInfo.from(it).cameraId == cameraId }
            })
            .build()
    }

    private fun bind(cameraId: String?, zoomAfter: Float?) {
        val p = provider ?: return
        // PreviewView only has a ViewPort once it has been laid out.
        val viewPort = previewView.viewPort
        if (viewPort == null && retries < 20) {
            retries++
            previewView.postDelayed({ bind(cameraId, zoomAfter) }, 50)
            return
        }
        retries = 0
        boundId = cameraId

        val ratio = AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
        val preview = Preview.Builder()
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setAspectRatioStrategy(ratio)
                    .setResolutionStrategy(
                        ResolutionStrategy(
                            Size(1920, 1080),
                            ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                        )
                    )
                    .build()
            )
            .build()
        preview.setSurfaceProvider(previewView.surfaceProvider)

        val capture = ImageCapture.Builder()
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setAspectRatioStrategy(ratio)
                    .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
                    .build()
            )
            .setFlashMode(flashMode)
            .setJpegQuality(95)
            .setTargetRotation(rotation)
            .build()

        val group = UseCaseGroup.Builder().addUseCase(preview).addUseCase(capture)
        if (viewPort != null) group.setViewPort(viewPort)

        try {
            p.unbindAll()
            val cam = p.bindToLifecycle(activity, selector(cameraId), group.build())
            camera = cam
            imageCapture = capture

            zoomLive?.removeObserver(zoomObserver)
            zoomLive = cam.cameraInfo.zoomState.also { it.observe(activity, zoomObserver) }

            if (zoomAfter != null) cam.cameraControl.setZoomRatio(zoomAfter)
            if (exposureNorm != 0f) setExposure(exposureNorm)

            onBound?.invoke(
                cam.cameraInfo.hasFlashUnit(),
                cam.cameraInfo.exposureState.isExposureCompensationSupported
            )
        } catch (e: Exception) {
            // A standalone camera id that CameraX refuses: fall back to the default back camera.
            if (cameraId != null) {
                displayBase = 1f
                bind(null, null)
            }
        }
    }

    // ---------------------------------------------------------------- lenses & zoom

    fun selectLens(l: LensProbe.Lens) {
        zoomAnim?.cancel()
        if (l.front) {
            if (front) return
            front = true
            displayBase = 1f
            bind(null, null)
            return
        }
        val needRebind = front || l.cameraId != boundId
        front = false
        if (needRebind) {
            displayBase = if (l.cameraId != null) l.ratio else 1f
            bind(l.cameraId, l.zoom)
        } else {
            zoomTo(l.zoom)
        }
    }

    fun zoomTo(target: Float, animate: Boolean = true) {
        val cam = camera ?: return
        val zs = cam.cameraInfo.zoomState.value ?: return
        val t = target.coerceIn(zs.minZoomRatio, zs.maxZoomRatio)
        zoomAnim?.cancel()
        if (!animate) {
            cam.cameraControl.setZoomRatio(t)
            return
        }
        zoomAnim = ValueAnimator.ofFloat(zs.zoomRatio, t).apply {
            duration = 280
            interpolator = DecelerateInterpolator()
            addUpdateListener { cam.cameraControl.setZoomRatio(it.animatedValue as Float) }
            start()
        }
    }

    fun zoomBy(factor: Float) {
        val cam = camera ?: return
        val zs = cam.cameraInfo.zoomState.value ?: return
        zoomAnim?.cancel()
        val t = (zs.zoomRatio * factor).coerceIn(zs.minZoomRatio, zs.maxZoomRatio)
        cam.cameraControl.setZoomRatio(t)
    }

    // ---------------------------------------------------------------- exposure / focus / flash

    /** @param v -1..1 across the full compensation range. Returns the resulting EV value. */
    fun setExposure(v: Float): Float {
        exposureNorm = v
        val cam = camera ?: return 0f
        val st = cam.cameraInfo.exposureState
        if (!st.isExposureCompensationSupported) return 0f
        val r = st.exposureCompensationRange
        val idx = if (v >= 0f) Math.round(v * r.upper) else Math.round(v * -r.lower)
        cam.cameraControl.setExposureCompensationIndex(idx)
        return idx * st.exposureCompensationStep.toFloat()
    }

    fun focus(x: Float, y: Float) {
        val cam = camera ?: return
        val point = previewView.meteringPointFactory.createPoint(x, y)
        val action = FocusMeteringAction.Builder(
            point,
            FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
        ).setAutoCancelDuration(4, TimeUnit.SECONDS).build()
        cam.cameraControl.startFocusAndMetering(action)
    }

    fun setFlash(mode: Int) {
        flashMode = mode
        imageCapture?.flashMode = mode
    }

    fun setRotation(r: Int) {
        rotation = r
        imageCapture?.targetRotation = r
    }

    // ---------------------------------------------------------------- capture

    /** Writes the raw JPEG to a temp file; PhotoSaver applies the film look and stores it. */
    fun capture(onResult: (java.io.File?) -> Unit) {
        val ic = imageCapture
        if (ic == null) {
            onResult(null)
            return
        }
        val file = try {
            java.io.File.createTempFile("zess_", ".jpg", activity.cacheDir)
        } catch (e: Exception) {
            onResult(null)
            return
        }
        val options = ImageCapture.OutputFileOptions.Builder(file).build()
        ic.takePicture(options, mainExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) = onResult(file)
            override fun onError(exception: ImageCaptureException) {
                file.delete()
                onResult(null)
            }
        })
    }
}
