package com.zess.camera

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.media.ExifInterface
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import java.io.File
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.hypot

/**
 * Takes the JPEG CameraX wrote to a temp file, applies the film look (if any) and stores the
 * result in Pictures/ZESS. The untouched version is never added to the gallery.
 * Work happens on a background thread; the photo stays "pending" (invisible) until it is done.
 */
object PhotoSaver {

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun save(ctx: Context, temp: File, look: FilmLook, onDone: (Boolean) -> Unit) {
        val app = ctx.applicationContext
        executor.execute {
            val ok = try {
                saveBlocking(app, temp, look)
            } catch (e: Throwable) {
                false
            } finally {
                temp.delete()
            }
            main.post { onDone(ok) }
        }
    }

    private fun saveBlocking(ctx: Context, temp: File, look: FilmLook): Boolean {
        val resolver = ctx.contentResolver
        val name = "ZESS_" + SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/ZESS")
            put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis())
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false

        var done = false
        try {
            var processed = false
            if (look != FilmLook.ORIGINAL) {
                processed = try {
                    resolver.openOutputStream(uri, "wt")!!.use { out -> render(temp, look, out) }
                    true
                } catch (e: Throwable) {
                    false   // e.g. out of memory: fall back to the plain photo below
                }
            }
            if (!processed) {
                resolver.openOutputStream(uri, "wt")!!.use { out ->
                    temp.inputStream().use { it.copyTo(out) }
                }
            }
            done = true
        } finally {
            if (done) {
                resolver.update(
                    uri,
                    ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) },
                    null, null
                )
            } else {
                resolver.delete(uri, null, null)
            }
        }
        return done
    }

    private fun render(src: File, look: FilmLook, out: OutputStream) {
        val orientation = ExifInterface(src.absolutePath)
            .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        val bmp = BitmapFactory.decodeFile(src.absolutePath)
            ?: throw IllegalStateException("decode failed")

        // Bake the EXIF rotation into the pixels (the output has no EXIF).
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                m.postRotate(90f)
                m.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                m.postRotate(-90f)
                m.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(-90f)
        }
        val box = RectF(0f, 0f, bmp.width.toFloat(), bmp.height.toFloat())
        m.mapRect(box)
        m.postTranslate(-box.left, -box.top)
        val w = Math.round(box.width())
        val h = Math.round(box.height())

        val dst = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(dst)

        // 1. colour
        val colorPaint = Paint(Paint.FILTER_BITMAP_FLAG)
        look.colorMatrix?.let { colorPaint.colorFilter = ColorMatrixColorFilter(it) }
        canvas.drawBitmap(bmp, m, colorPaint)
        bmp.recycle()

        val full = RectF(0f, 0f, w.toFloat(), h.toFloat())

        // 2. vignette
        if (look.vignette > 0f) {
            val vp = Paint()
            vp.shader = RadialGradient(
                w / 2f, h / 2f, hypot(w.toFloat(), h.toFloat()) / 2f,
                intArrayOf(0, 0, Color.BLACK), floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
            vp.alpha = (look.vignette * 255).toInt()
            canvas.drawRect(full, vp)
        }

        // 3. grain (scaled so the speck size matches the live preview)
        if (look.grain > 0f) {
            val bs = BitmapShader(FilmLook.noise, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
            val gm = Matrix()
            val s = w / 1080f * 1.5f
            gm.setScale(s, s)
            bs.setLocalMatrix(gm)
            val gp = Paint(Paint.FILTER_BITMAP_FLAG)
            gp.shader = bs
            gp.alpha = (look.grain * 110).toInt()
            canvas.drawRect(full, gp)
        }

        dst.compress(Bitmap.CompressFormat.JPEG, 95, out)
        dst.recycle()
    }
}
